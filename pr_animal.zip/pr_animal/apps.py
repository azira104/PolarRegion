from django.apps import AppConfig


class PrAnimalConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pr_animal'
